/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 *
 * @author hvtrung
 */
public class Panel {
    
    private ArrayList<Button> bton;
    
    public Panel(){
        bton = new ArrayList<Button>();
    }
    

    public void update() {
        for(Button b : bton){
            b.update();
        }
    }

    public void render(Graphics2D g) {
        for(Button b: bton){
            b.render(g);
        }
    }
    
    public void add(Button button){
        bton.add(button);
    }
    public void remove(Button button){
        bton.remove(button);
    }
    
    
    public void mousePressed(MouseEvent e) {
        for(Button b : bton){
            b.mousePressed(e);
        }
    }

    public void mouseDragged(MouseEvent e) {
        for(Button b : bton){
            b.mouseDragged(e);
        }
    }

    public void mouseReleased(MouseEvent e) {
        for(Button b : bton){
            b.mouseReleased(e);
        }
    }

    public void mouseMoved(MouseEvent e) {
        for(Button b : bton){
            b.mouseMoved(e);
        }
    }
}
