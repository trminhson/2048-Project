/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2048;
import java.awt.event.KeyEvent;
import java.util.Random;
/**
 *
 * @author trufmgajtgiof
 */
public class Game2048 {
    private int[][] board;    
    public boolean lose = false;
    public boolean win = false;
    public int score = 0;
    private int highestScore = 0;
    public void setHighestScore(int s){
        highestScore = s;
    }
    
    //constructor
    public Game2048(){
        newGame();
        
    }
    
    //newGame method
    public void newGame(){
        score = 0;
        lose = false;
        win = false;
        board = new int[4][4];
        for (int i=0; i<4; i++)
            for (int j=0; j<4; j++)
                board[i][j] = 0;
    }
    
    //display method
    public void display(){
        for (int i=0; i<4; i++){
            for (int j=0; j<4; j++)
                System.out.print(""+board[i][j]+"\t");
            System.out.print("\n");
        }
    }
    
    //
    public void addTile(){
        
    }
    //main
    public static void main(String[] args){
        Game2048 g1 = new Game2048();
        g1.display();
    }
}
